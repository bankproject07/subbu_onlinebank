package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.jboss.security.auth.spi.Users.User;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.util.DBUtil;

public class UserDAOImpl implements IUserDAO {

	PreparedStatement pst;
	Connection con;
	Statement st;
	@Override
	public Users getUser(String id) throws UserException {
		
		Users user=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM USERTABLE WHERE ACCOUNTID=?";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			user=new Users();
			user.setAccountId(rs.getInt(1));
			user.setUserId(rs.getString(2));
			user.setLoginPassword(rs.getString(3));
			user.setSecretQuestion(rs.getString(4));
			user.setLockStatus(rs.getString(5));
			user.setTransPassword(rs.getString(6));
			
		}
		catch (SQLException e) 
		{
			throw new UserException("Something went wrong while Retrieving User Data");
		}
		return user;
	}

	@Override
	public Admin getAdmin(String id) throws UserException {
		Admin admin=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Admin";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			admin=new Admin();
			admin.setAdminid(rs.getString(1));
			admin.setAdminPassword(rs.getString(2));
			
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return admin;
	}

	@Override
	public int addUser(Users user) throws UserException 
	{
		int generateID = -1;
		try(Connection con = DBUtil.getConnection())		//because of this connection automatically close.
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select user_seq.nextval from dual");
			
			if(res.next()==false)
				
			{
				throw new UserException("Something went wrong while generating Booking ID.");
			}
			int uid = res.getInt(1);
			int accid =user.getAccountId();
			String loginPass = user.getLoginPassword();
			String secretQuestn = user.getSecretQuestion();
			String answer = user.getAnswer();
			String transPass = user.getTransPassword();
			String lockStatus = user.getLockStatus();
			
			PreparedStatement pstm = con.prepareStatement("insert into enquiry values(?,?,?,?,?,?,?)");
			
			pstm.setInt(1, uid);
			pstm.setInt(2, accid);
			pstm.setString(3, loginPass);
			pstm.setString(4, secretQuestn);
			pstm.setString(5, answer);
			pstm.setString(6, transPass);
			pstm.setString(7, lockStatus);
			
			pstm.execute();
			
			generateID =  uid;
		
			
		}
		catch(Exception e)
		{
			
		}
		
		return generateID;
	}

}
