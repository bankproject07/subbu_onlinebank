package com.cg.obs.dao;

import org.jboss.security.auth.spi.Users.User;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;

public interface IUserDAO
{
	public int addUser(Users user) throws UserException;
	public Users getUser(String id) throws UserException;
	public Admin getAdmin(String id) throws UserException;
}
