package com.cg.obs.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;


@WebServlet(urlPatterns={"/BankingApplicationController","/Login"})
public class BankingApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService;
    public BankingApplicationController() {
        
    	userService=new UserServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		String url="";
		
		switch(path)
		{
		case "/Login":
			
			String id=request.getParameter("txtUserName");
			String password=request.getParameter("txtPassword");
			Users user=userService.getUser(id);
			if(user!=null)
				{
					if(password==user.getLoginPassword())
					{
						url="Sucess.jsp";
						request.setAttribute("userid", user.getUserId());
					}
					else
					{
						url="Failure.jsp";
					}
				}
			else
			{
				throw new UserException("No User Exists.....");
			}
			
			
			}
				
			RequestDispatcher rd=request.getRequestDispatcher(url);
			rd.forward(request, response);
			
			
			
		}
		
		
		
		
	}


