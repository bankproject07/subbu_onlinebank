package com.cg.obs.bean;

public class Customer
{
	private int accountId;
	private String custName;
	private String emailId;
	private String address;
	private String pancard;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public Customer(int accountId, String custName, String emailId,
			String address, String pancard) {
		super();
		this.accountId = accountId;
		this.custName = custName;
		this.emailId = emailId;
		this.address = address;
		this.pancard = pancard;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [accountId=" + accountId + ", custName=" + custName
				+ ", emailId=" + emailId + ", address=" + address
				+ ", pancard=" + pancard + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (accountId != other.accountId)
			return false;
		return true;
	}
	
	
}
